<div class="container-fluid">
	<div class="row">
	    <div class="col-12 col-sm-12 col-md-1 col-lg-1"></div>
        <div class="col-12 col-sm-12 col-md-10 col-lg-10 zigzagAndFace textWhite shadowBlueOut">
            <div class="row">
                <div class="col-3 col-sm-3 col-md-3 col-lg-1 zigzagProfileImg">
                    <img src="/files/images/userProfiles/3e/52/2f/c0/3e522fc04dd6f25a8015ffa15af92b2b.jpg"></img>
                </div>
                <div class="col-5 col-sm-3 col-md-3 col-lg-1">
                    <p>Apex Pilipenko</p>
                </div>
                <div class="col-12 col-sm-12 col-md-1 col-lg-8"></div>
                <div class="col-12 col-sm-12 col-md-1 col-lg-1"></div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-1 col-lg-1"></div>
    </div>
</div>